﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using ClosedXML.Excel;
using System.Windows.Threading;
using System.Windows.Controls.Primitives;

namespace MphasisCalendar
{
    public partial class MainWindow : Window
    {
        private HashSet<DateTime> companyHolidays = new();
        private HashSet<DateTime> optionalHolidays = new();

        public MainWindow()
        {
            InitializeComponent();
            LoadHolidayDataFromExcel();

            myCalendar.DisplayDateChanged += (s, e) => HighlightCalendarDates();
            myCalendar.Loaded += (s, e) => HighlightCalendarDates();
        }

        private void LoadHolidayDataFromExcel()
        {
            string excelPath = "MphasisHoliDay.xlsx";
            if (!File.Exists(excelPath))
            {
                MessageBox.Show("Holiday Excel file not found.");
                return;
            }

            using var workbook = new XLWorkbook(excelPath);
            var worksheet = workbook.Worksheet(1);
            int row = 2;

            while (true)
            {
                var dateCell = worksheet.Cell(row, 1);
                if (dateCell.IsEmpty())
                    break;

                if (DateTime.TryParse(dateCell.GetValue<string>(), out DateTime holidayDate))
                {
                    var allLocationsCell = worksheet.Cell(row, 3); // "All Other Locations"
                    string allLocationValue = allLocationsCell.GetString().Trim();

                    bool isCompanyHoliday = allLocationValue == "*";
                    bool isOptionalHoliday = !isCompanyHoliday;

                    // Check for * in other columns (State Optional Holidays)
                    for (int col = 4; col <= worksheet.LastColumnUsed().ColumnNumber(); col++)
                    {
                        if (worksheet.Cell(row, col).GetString().Trim() == "*")
                        {
                            if (!isCompanyHoliday)
                                optionalHolidays.Add(holidayDate);
                            break;
                        }
                    }

                    if (isCompanyHoliday)
                        companyHolidays.Add(holidayDate);
                }

                row++;
            }
        }

        private void HighlightCalendarDates()
        {
            Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
            {
                var monthStart = new DateTime(myCalendar.DisplayDate.Year, myCalendar.DisplayDate.Month, 1);
                var monthEnd = monthStart.AddMonths(1).AddDays(-1);

                foreach (var item in FindVisualChildren<CalendarDayButton>(myCalendar))
                {
                    if (item.DataContext is DateTime date)
                    {
                        if (companyHolidays.Contains(date.Date))
                        {
                            item.Background = Brushes.LightGreen; // 🟩
                        }
                        else if (optionalHolidays.Contains(date.Date))
                        {
                            item.Background = Brushes.LightYellow; // 🟨
                        }
                        else if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday)
                        {
                            item.Background = Brushes.LightBlue; // 🔵
                        }
                        else
                        {
                            item.ClearValue(BackgroundProperty); // Default
                        }
                    }
                }
            }));
        }

        private static IEnumerable<T> FindVisualChildren<T>(DependencyObject depObj) where T : DependencyObject
        {
            if (depObj == null) yield break;

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(depObj, i);
                if (child is T t)
                    yield return t;

                foreach (T childOfChild in FindVisualChildren<T>(child))
                    yield return childOfChild;
            }
        }
    }
}
