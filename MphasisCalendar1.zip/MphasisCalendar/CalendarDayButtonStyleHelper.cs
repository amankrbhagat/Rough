﻿//using System;
//using System.Collections.Generic;
//using System.Windows.Controls;
//using System.Windows.Controls.Primitives;
//using System.Windows.Media;

//public static class CalendarDayButtonStyleHelper
//{
//    public static void SetCustomDayStyles(Calendar calendar, Dictionary<DateTime, string> holidayMap)
//    {
//        calendar.Loaded += (s, e) =>
//        {
//            var dayButtons = FindDayButtons(calendar);

//            foreach (var button in dayButtons)
//            {
//                if (button.DataContext is DateTime date)
//                {
//                    if (holidayMap.TryGetValue(date.Date, out string type))
//                    {
//                        // 🟩 Green for Company Holiday
//                        if (type.Equals("Company Holiday", StringComparison.OrdinalIgnoreCase))
//                            button.Background = Brushes.LightGreen;

//                        // 🟨 Yellow for Optional Holiday
//                        else if (type.Equals("Optional Holiday", StringComparison.OrdinalIgnoreCase))
//                            button.Background = Brushes.LightYellow;
//                    }
//                    else if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday)
//                    {
//                        // 🔵 Blue for weekends
//                        button.Background = Brushes.LightBlue;
//                    }
//                }
//            }
//        };
//    }

//    private static IEnumerable<CalendarDayButton> FindDayButtons(Calendar calendar)
//    {
//        var dayButtons = new List<CalendarDayButton>();
//        var calendarItem = (CalendarItem)calendar.Template.FindName("PART_CalendarItem", calendar);

//        if (calendarItem != null)
//        {
//            calendarItem.ApplyTemplate();
//            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(calendarItem); i++)
//            {
//                var child = VisualTreeHelper.GetChild(calendarItem, i);
//                if (child is CalendarDayButton button)
//                {
//                    dayButtons.Add(button);
//                }
//            }
//        }
//        return dayButtons;
//    }
//}
